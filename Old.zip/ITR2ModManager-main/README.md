# ITR2ModManager
A Mod Manager for Into The Radius 2 based on python allowing you to install mods as zip files into itr2

this project is mainly for thos who have issue with the vortex mod manager this should fix random crashes and missing modded texture
also support fomod

https://youtu.be/EcdXIeFZmi0
https://www.nexusmods.com/intotheradius2/mods/66?tab=description

code edited at 60% by chatgpt all comment are writen by chatgpt
